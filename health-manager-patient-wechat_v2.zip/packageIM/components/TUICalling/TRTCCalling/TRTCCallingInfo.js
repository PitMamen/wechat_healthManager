const TRTCCallingInfo = {
  'name': 'trtcalling',
  'version': '1.0.0',
  'description': 'TRTCCalling miniProgram',
  'main': 'TRTCCalling.js',
  'author': '',
  'license': 'ISC',
}

export default TRTCCallingInfo
